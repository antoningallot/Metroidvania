open Tsdl;;

type kind =
  |Perso
  |Ennemi
  |Plateforme
  |Mur
  |Missile
  |Wallpaper
      
type position = {x : int; y : int};;

type vitesse = {vx : int; vy : int};;

type objet = {pos : position;
	      oldpos : position;
	      speed : vitesse;
	      kind : kind;
	      w : int;
	      h : int;
	      texture: Sdl.texture;
	      jumping : bool;
	      niv : int;
	      pv : int;
	      timer_collision : int;
	      timer_missile : int;
	      frame : int;
	      repos : int;
	      wl : Sdl.texture array;
	      wr : Sdl.texture array;
	      jl : Sdl.texture array;
	      jr : Sdl.texture array;
	      s : Sdl.texture array;
	      m : Sdl.texture array
	     };;

exception Erreur;;

let base_speed_x = 0;;
let base_speed_y = 1;;
let base_incr_speed_x = 10;;
let timer_marche = 3;;
let timer_saut = 5;;
let timer_repos = 5;;
let repos_walk = 5;;
let repos_jump = 5;;

let creer_perso x y width height text lvl wl wr jl jr s m=
  let pos = {x=x;y=y} in
  let speed = {vx = base_speed_x; vy = base_speed_y} in
  {pos = pos; oldpos= pos; speed=speed; kind=Perso; w=width; h=height; texture=text; jumping=false; niv = lvl; pv = 5; timer_collision = 0; timer_missile = 0; frame = 0; repos = 35; wl = wl; wr = wr; jl = jl; jr = jr; s = s; m = m}
;;

let creer_ennemi x y width height text lvl =
  let pos = {x=x;y=y} in
  let speed = {vx = base_speed_x; vy = base_speed_y} in
  {pos = pos; oldpos= pos; speed=speed; kind=Ennemi; w=width; h=height; texture=text; jumping=false; niv = lvl; pv = 2; timer_collision = 0; timer_missile = 0; frame = 0; repos = 0; wl =[||]; wr = [||]; jl =[||]; jr = [||]; s = [||]; m = [||] }
;;

let creer_plateforme x y width height text lvl =
  let pos = {x=x;y=y} in
  let speed = {vx = 0; vy = 0} in
  {pos = pos; oldpos= pos; speed=speed; kind=Plateforme; w=width; h=height; texture=text; jumping=false; niv = lvl; pv = 1; timer_collision = 0; timer_missile = 0; frame = 0; repos = 0; wl =[||]; wr = [||]; jl =[||]; jr = [||]; s = [||]; m = [||] }
;;

let creer_mur x y width height text lvl =
  let pos = {x=x;y=y} in
  let speed = {vx = 0; vy = 0} in
  {pos = pos; oldpos= pos; speed=speed; kind=Mur; w=width; h=height; texture=text; jumping=false; niv = lvl; pv = 1; timer_collision = 0; timer_missile = 0; frame = 0; repos = 0; wl =[||]; wr = [||]; jl =[||]; jr = [||];  s = [||]; m = [||] }
;;


let kind_to_string o =
  match o.kind with
  |Perso -> Printf.printf "Perso\n";
  |Plateforme -> Printf.printf "Plateforme\n";
  |Mur -> Printf.printf "Mur\n";
  |Missile -> Printf.printf "Missile\n";
  |Ennemi -> Printf.printf "Ennemi\n";
  |Wallpaper -> Printf.printf "Wallpaper\n";
;;

let move_objet o =
  if o.kind = Plateforme || o.kind = Mur then o
  else if o.kind = Missile then
    {o with pos = {o.pos with x = o.pos.x + o.speed.vx}; oldpos = o.pos}
  else if o.kind = Ennemi then
    {o with pos = {x = o.pos.x + o.speed.vx; y = o.pos.y + o.speed.vy};
      oldpos = o.pos;
      speed = {vx = o.speed.vx; vy = o.speed.vy+1}}
  else
    {o with pos = {x = o.pos.x+o.speed.vx; y = o.pos.y + o.speed.vy};oldpos = o.pos;speed = {vx = base_speed_x; vy = o.speed.vy+1}}
;;


let remove_objet l o =
  let rec aux l acc =
    match l with
    |[] -> acc
    |h::t -> if h = o then aux t acc else aux t (h::acc)
  in aux l []
;;

let is_in_window p =
  if p.pos.x >= 0 && p.pos.x+p.w <= 1920 && p.pos.y >= 0 && p.pos.y+p.h <= 1080 then true else false
;;

let is_dead o = o.pv = 0;;

let remove_if_dead l =
  let rec aux l acc =
    match l with
    |[] -> acc
    |h::t -> if is_dead h then aux t acc else aux t (h::acc)
  in aux l []
;;

let check_collision a b =
  let rectA = Sdl.Rect.create (a.pos.x+a.speed.vx) (a.pos.y+a.speed.vy) a.w a.h in
  let rectB = Sdl.Rect.create (b.pos.x+b.speed.vx) (b.pos.y+b.speed.vy) b.w b.h in
  if Sdl.has_intersection rectA rectB then true else false
;;

let collision_right o1 o2 =
  o1.oldpos.x <= o2.oldpos.x && o1.oldpos.y + o1.h > o2.oldpos.y && o1.oldpos.y < o2.oldpos.y + o2.h
;;

let collision_left o1 o2 =
  o1.oldpos.x >= o2.oldpos.x+o2.w && o1.oldpos.y + o1.h > o2.oldpos.y && o1.oldpos.y < o2.oldpos.y + o2.h
;;

let collision_down o1 o2 =
  o1.oldpos.y <= o2.oldpos.y && o1.oldpos.y+o1.h <= o2.oldpos.y
;;

let collision_up o1 o2 =
  o1.oldpos.y >= o2.oldpos.y+o2.h && o1.oldpos.y >= o2.oldpos.y + o2.h
;;
