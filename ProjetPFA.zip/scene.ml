open Tsdl;;
open Objet;;
open Array;;

type state =
    Menu
  |Game
;;

type scene = {
  window : Sdl.window;
  renderer : Sdl.renderer;
  wallpaper : Sdl.texture;
  state : int;(*0 = menu, 1 = game*)
  objets : objet list
};;


type direction =
    Right
  |Left
  |Jump
  |Down
  |Missile
;;

let wall = ("wall.bmp",Mur, 1500,100,0);;
let niveau1 = [("Sprite/M1.bmp", Wallpaper, 0,0,0);("Sprite/S1.bmp",Perso,960,500,0);
	       ("sol.bmp",Plateforme,0,990,0);("Ennemi_grand.bmp",Ennemi,400,390,0); ("Plateforme.bmp",Plateforme,870,850,0)];;
   (*let niveau1 = [("castlevania.bmp", Wallpaper, 0,0,0);("DIO.bmp",Perso,960,400,0);
  ("sol.bmp",Plateforme,0,990,0)];;*)
let niveau2 = [("street.bmp","wallpaper",0,0,1); ("DIO.bmp","perso",960,500,0);("sol.bmp","plateforme",0,990,1)];;
let menu = [("menu.bmp",Wallpaper,0,0,0)];;
let jl = [|"Sprite/JL1.bmp";"Sprite/JL2.bmp";"Sprite/JL3.bmp";"Sprite/JL4.bmp"|];;
let jr = [|"Sprite/JR1.bmp";"Sprite/JR4.bmp";"Sprite/JR6.bmp";"Sprite/JR8.bmp"|];;
let wr = [|"Sprite/WR1.bmp";"Sprite/WR2.bmp";"Sprite/WR3.bmp";"Sprite/WR4.bmp";"Sprite/WR5.bmp";"Sprite/WR6.bmp";"Sprite/WR7.bmp";"Sprite/WR8.bmp";"Sprite/WR9.bmp";"Sprite/WR10.bmp";"Sprite/WR11.bmp";"Sprite/WR12.bmp";"Sprite/WR13.bmp";"Sprite/WR14.bmp";"Sprite/WR15.bmp";"Sprite/WR16.bmp";"Sprite/WR17.bmp"|];;
let wl = [|"Sprite/WL1.bmp";"Sprite/WL2.bmp";"Sprite/WL3.bmp";"Sprite/WL4.bmp";"Sprite/WL5.bmp";"Sprite/WL6.bmp";"Sprite/WL7.bmp";"Sprite/WL8.bmp";"Sprite/WL9.bmp";"Sprite/WL10.bmp";"Sprite/WL11.bmp";"Sprite/WL12.bmp";"Sprite/WL13.bmp";"Sprite/WL14.bmp";"Sprite/WL15.bmp";"Sprite/WL16.bmp";"Sprite/WL17.bmp"|];;
let s = [|"Sprite/S1.bmp";"Sprite/S2.bmp";"Sprite/S3.bmp";"Sprite/S4.bmp";"Sprite/S5.bmp";"Sprite/S6.bmp";"Sprite/S7.bmp";"Sprite/S8.bmp";"Sprite/S9.bmp";"Sprite/S10.bmp";"Sprite/S11.bmp";"Sprite/S12.bmp";"Sprite/S13.bmp";"Sprite/S14.bmp";"Sprite/S15.bmp";"Sprite/S16.bmp";"Sprite/S17.bmp";"Sprite/S18.bmp";"Sprite/S19.bmp";"Sprite/S20.bmp";"Sprite/S21.bmp";"Sprite/S22.bmp";"Sprite/S23.bmp";"Sprite/S24.bmp";"Sprite/S25.bmp";"Sprite/S26.bmp";"Sprite/S27.bmp";"Sprite/S28.bmp";"Sprite/S29.bmp";"Sprite/S30.bmp";"Sprite/S31.bmp";"Sprite/S32.bmp";"Sprite/S33.bmp";"Sprite/S34.bmp";"Sprite/S35.bmp";"Sprite/S36.bmp";"Sprite/S37.bmp";"Sprite/S36.bmp";"Sprite/S35.bmp";"Sprite/S34.bmp";"Sprite/S33.bmp";"Sprite/S32.bmp";"Sprite/S31.bmp";"Sprite/S30.bmp";"Sprite/S29.bmp";"Sprite/S28.bmp";"Sprite/S27.bmp";"Sprite/S26.bmp";"Sprite/S25.bmp";"Sprite/S24.bmp";"Sprite/S23.bmp";"Sprite/S22.bmp";"Sprite/S21.bmp";"Sprite/S20.bmp";"Sprite/S19.bmp";"Sprite/S18.bmp";"Sprite/S17.bmp";"Sprite/S16.bmp";"Sprite/S15.bmp";"Sprite/S14.bmp";"Sprite/S13.bmp";"Sprite/S12.bmp";"Sprite/S11.bmp";"Sprite/S10.bmp";"Sprite/S9.bmp";"Sprite/S8.bmp";"Sprite/S7.bmp";"Sprite/S6.bmp";"Sprite/S5.bmp";"Sprite/S4.bmp";"Sprite/S3.bmp";"Sprite/S2.bmp";"Sprite/S1.bmp"|];;
let m = [|"Sprite/MJR.bmp";"Sprite/MJL.bmp";"Sprite/MR.bmp";"Sprite/ML.bmp"|];;
let inv_sprite = "Sprite/vide.bmp";;
 

(*Initialise la sdl*)
let init () =
  match Sdl.init Sdl.Init.video with
  |Error (`Msg e) -> Sdl.log "Init error : %s" e; exit 1
  |Ok () -> ();;

(*Crée une fenetre*)
let create_window w h title =
  match Sdl.create_window ~w:w ~h:h title Sdl.Window.opengl with
  |Error (`Msg e) -> Sdl.log "Create window error : %s" e; exit 1
  |Ok w -> w;;

(*Crée un renderer*)
let create_renderer index flags w =
  match Sdl.create_renderer ~index:(index) ~flags:flags w  with
  |Error (`Msg e) -> Sdl.log "Create renderer error : %s" e; exit 1
  |Ok r -> r;;


(*Charge une image depuis son chemin, renvoie une surface*)
let load_img path =
  match Sdl.load_bmp path with
  |Error (`Msg e) -> Sdl.log "Load image error : %s" e; exit 1
  |Ok s -> s;;

let play_music s =
  match (Tsdl_mixer.Mixer.open_audio 44100 Tsdl_mixer.Mixer.default_format Tsdl_mixer.Mixer.default_channels 1024) with
  |Error (`Msg e) -> Sdl.log "Music error : %s" e; exit 1
  |Ok() -> 
     match (Tsdl_mixer.Mixer.load_mus s) with
     |Error (`Msg e) -> Sdl.log "Error Load Music : %s" e; exit 1
     |Ok m ->
	begin
	  match (Tsdl_mixer.Mixer.play_music m (-1)) with
	  |Error (`Msg e) -> Sdl.log "Music error : %s" e; exit 1
	  |Ok x -> ()
	end
;;

(*Crée une texture à partir d'une surface*)
let create_texture_from_surface r s  =
  match Sdl.create_texture_from_surface r s with
  |Error (`Msg e) -> Sdl.log "Create texture error : %s" e; exit 1
  |Ok t -> Sdl.free_surface s; t;;


(*Charge une texture directement depuis un nom de fichier*)
let img_to_texture r path = 
  let s = load_img path in
  create_texture_from_surface r s
;;

let load_tables renderer =
  let left = Array.init (length wl) (fun i -> img_to_texture renderer wl.(i)) in
  let right = Array.init (length wr) (fun i -> img_to_texture renderer wr.(i)) in
  let jump_left = Array.init (length jl) (fun i -> img_to_texture renderer jl.(i)) in
  let jump_right = Array.init (length jr) (fun i -> img_to_texture renderer jr.(i)) in
  let stand = Array.init (length s) (fun i -> img_to_texture renderer s.(i)) in
  let missile = Array.init (length m) (fun i -> img_to_texture renderer m.(i)) in
  (left,right, jump_left, jump_right, stand, missile)
;;

(*Prend une liste de (string * string * int * int * int) et renvoie une liste contenant les objets correspondants
avec leur texture, leur type, leur position de départ et leur niveau*)
let text_list_to_object_list l r =
  let rec aux l acc =
    match l with
    |[] -> acc
    |(path, kind, x, y, niv)::tl ->
       let surface = load_img path in
       let texture = create_texture_from_surface r surface in
       match Sdl.query_texture texture with
       |Error (`Msg e) -> Sdl.log "Create query texture error : %s" e; exit 1
       |Ok (_,_,(w,h)) ->
	  let (left, right, jump_left, jump_right, stand, missile) = load_tables r in
	  match kind with
	  |Perso -> let o = creer_perso x y w h texture niv left right jump_left jump_right stand missile in let acc = o::acc in aux tl acc
	  |Plateforme -> let o = creer_plateforme x y w h texture niv in let acc = o::acc in aux tl acc
	  |Mur -> let o = creer_mur x y w h texture niv in let acc = o::acc in aux tl acc
	  |Ennemi -> let o = creer_ennemi x y w h texture niv in let acc = o::acc in aux tl acc
	  |Wallpaper | Missile -> aux tl acc
  in aux l []
;;

let display scene o =
  match Sdl.query_texture o.texture with
  |Error (`Msg e) -> Sdl.log "Create query texture error : %s" e; exit 1
  |Ok (_,_,(w,h)) -> let destrect = Sdl.Rect.create o.pos.x o.pos.y o.w o.h in
		     Sdl.render_copy ~dst:destrect scene.renderer o.texture; 
;;		     

(*Affiche tous les éléments de la scène*)
let display_list scene =
  Sdl.delay 17l;
  Sdl.render_clear scene.renderer;
  Sdl.render_copy scene.renderer scene.wallpaper;
  let rec aux l =
    match l with
    |[] -> ()    
    |h::t -> display scene h;
      aux t
  in aux scene.objets
;;

let display_menu scene =
  Sdl.delay 17l;
  Sdl.render_clear scene.renderer;
  Sdl.render_copy scene.renderer scene.wallpaper;
;;

(*Crée une scène à partir d'une fenetre, d'un renderer, de deux listes de (string*int*int) et d'un nom de fichier*)
let create_scene w r lvl state =
  {window = w;
   renderer = r;
   wallpaper = (match (List.hd lvl) with
   |(s,_,_,_,_) -> img_to_texture r s);
   state = state;
   objets = text_list_to_object_list lvl r
  }
;;

let load_menu s =
  create_scene s.window s.renderer menu 0
;;

let get_perso s =
  let rec aux l =
    match l with
    |[] -> Printf.printf "Erreur"; raise Erreur
    |h::t -> begin
      match h.kind with
      |Perso -> h
      |_ -> aux t
    end
  in aux s.objets
;;

let update_perso s p =
  let oldp = get_perso s in
  {s with objets = p::(remove_objet s.objets oldp)}
;;

(*
let create_scene_right s =
  let temp_scene = create_scene s.window s.renderer niveau2 1 in
  let new_scene = {temp_scene with perso = {s.perso with pos = {s.perso.pos with x = 0}; niv = s.perso.niv+1}} in
  display_list new_scene;
  new_scene
;;

let create_scene_left s =
  let temp_scene = create_scene s.window s.renderer niveau1 1 in
  let new_scene = {temp_scene with perso = {s.perso with pos = {s.perso.pos with x = 1920-s.perso.l}; niv = s.perso.niv-1}} in
  display_list new_scene;
  new_scene
  ;;
*)

let creer_missile_right_obj s text=
  let p = get_perso s in
  let pos = {x=p.pos.x+p.w+7; y=p.pos.y+22} in
  {pos= pos; oldpos = pos; speed={vx=10; vy=0}; kind = Missile; w=25; h=10; texture = text;
   jumping = false; niv = p.niv; pv = 1; timer_collision = 0; timer_missile = 0; frame = 0; repos = 0; wl = [||]; wr = [||]; jl =[||]; jr = [||];  s = [||]; m = [||] }
;;

let creer_missile_left_obj s text=
  let p = get_perso s in
  let pos = {x=p.pos.x-25; y=p.pos.y+22} in
  {pos= pos; oldpos = pos; speed={vx= (-10); vy=0}; kind = Missile; w=25; h=10;
   texture = text; jumping = false; niv = p.niv; pv = 1;timer_collision = 0; timer_missile = 0; frame = 0; repos = 0; wl = [||]; wr = [||]; jl =[||]; jr = [||];  s = [||]; m = [||] }
;;

let creer_missile_left s =
  let newproj = creer_missile_left_obj s (img_to_texture s.renderer "Sprite/couteau2.bmp") in
  let p = {(get_perso s) with timer_missile = 1} in
  let l = (remove_objet s.objets (get_perso s))@[newproj]@[p] in
  {s with objets = l}
;;

let creer_missile_right s =
  let newproj = creer_missile_right_obj s (img_to_texture s.renderer "Sprite/couteau1.bmp") in
  let p = {(get_perso s) with timer_missile = 1} in
  let l = (remove_objet s.objets (get_perso s))@[newproj]@[p] in
  {s with objets = l}
;;


let creer_missiles s m =
  let p = get_perso s in
  if p.timer_missile <> 0 || m = 0 then s
  else
    begin
      if m > 0 then
    creer_missile_right s
      else creer_missile_left s
    end
;;

(*
let change_niveau s dir =
  (*Printf.printf "Change niveau\n";*)
  match dir with
  |None -> s
  |Some d -> if d = Right then begin
    if s.perso.niv = 0 then create_scene_right s else s
  end
    else begin
      if s.perso.niv = 1 then create_scene_left s else s
    end
  ;;*)

let move_objet_list l =
  let rec aux l acc =
    match l with
    |[] -> acc
    |h::t -> if is_in_window h then
	begin
	  let acc = (move_objet h)::acc in
	  aux t acc
	end
      else let acc = remove_objet acc h in
	   aux t acc
  in aux l []
;;

let collision_perso p o =
  match o.kind with
  |Missile | Wallpaper | Perso -> p
  |Ennemi ->
     if p.timer_collision = 0 then
       begin
	 if collision_right p o then
           {p with  pv = p.pv-1; timer_collision = 1}
	 else if collision_left p o then
           {p with pv = p.pv-1; timer_collision = 1}
	 else if collision_up p o then
           {p with pv = p.pv-1; timer_collision = 1}
	 else
           {p with pv = p.pv-1;jumping = false; timer_collision = 1}
       end
     else
       p
  |Plateforme ->
     begin
       if collision_down p o then
	 {p with pos = {p.pos with y = o.pos.y-p.h}; speed = {vx = base_speed_x; vy = 0}; jumping = false}
       else p
     end
  |Mur -> 
     begin
       if collision_right p o then
	 {p with pos = {p.pos with x = o.pos.x-p.w}; speed = {vx = base_speed_x; vy = p.speed.vy}}
       else if collision_left p o then 
	 {p with pos = {p.pos with x = o.pos.x+o.w}; speed = {vx = base_speed_x; vy = p.speed.vy}}
       else if collision_up p o then
	 {p with pos = {p.pos with y = o.pos.y+o.h}; speed = {vx = base_speed_x; vy = p.speed.vy}}
       else
	 {p with pos = {p.pos with y = o.pos.y-p.h}; speed = {vx = base_speed_x; vy = 0}; jumping = false; frame = 0}
     end
;;

let collision_ennemi e o =
  match o.kind with
  |Perso| Ennemi | Wallpaper -> e
  |Missile -> {e with pv = e.pv-1}
  |Mur | Plateforme ->
    begin
      if collision_right e o then
	{e with pos = {e.pos with x = o.pos.x-e.w}; speed = {vx = (-e.speed.vx); vy = base_speed_y}}
      else if collision_left e o then 
	{e with pos = {e.pos with x = o.pos.x+o.w}; speed = {vx = (-e.speed.vx); vy = base_speed_y}}
      else if collision_up e o then
	{e with pos = {e.pos with y = o.pos.y+o.h}; speed = {vx = e.speed.vx; vy = base_speed_y}}
      else {e with pos = {e.pos with y = o.pos.y-e.h}; speed = {vx = e.speed.vx; vy = 0}}
    end
;;

let collision_missile m o =
  match o.kind with
  |Perso | Missile | Wallpaper -> m
  |Ennemi | Mur | Plateforme -> {m with pv = 0}
;;
     
let collision o1 o2 =
  if check_collision o1 o2 then
    begin
      match o1.kind with
      |Perso -> collision_perso o1 o2
      |Ennemi -> collision_ennemi o1 o2
      |Missile -> collision_missile o1 o2
      |Plateforme | Mur | Wallpaper -> o1
    end
  else o1
;;

let check_collision_all s =
  {s with objets = List.map (fun o -> (List.fold_left collision o (remove_objet s.objets o))) s.objets}
;;

let moveall scene =
  let s = {scene with objets = move_objet_list scene.objets} in
  check_collision_all  s
;;


let check_inv s p t m =
  if p.timer_collision <> 0 && p.frame mod 3 = 0 then
    (img_to_texture s.renderer inv_sprite)
  else if p.timer_missile >= 1 then
    begin
      if p.jumping then
	if m>0 then p.m.(0)
	else p.m.(1)
      else
	if m>0 then p.m.(2)
	else p.m.(3)
    end
  else t
;;
  
    
let check_texture s p (vx, vy) m =
  if p.jumping then
    begin
      if vx >= 0 then (check_inv s p p.jr.(p.frame/timer_saut) m, (if (p.frame/timer_saut) < 3 then p.frame+1 else 15), repos_jump)
      else (check_inv s p p.jl.(p.frame/timer_saut) m,(if (p.frame/timer_saut) < 3 then p.frame+1 else 15) ,repos_jump)
    end
  else if vy < 0 then
    begin
      if vx >= 0 then
	(check_inv s p p.jr.(0) m, 0 , 30)
      else
	(check_inv s p p.jl.(0) m, 0, repos_jump)
    end
  else
    begin
      if vx > 0 then
	begin
	  if p.repos <> 0 then 
	    (check_inv s p p.wr.(p.frame/timer_marche) m, (p.frame mod 50)+1, repos_walk)
	  else
	    (check_inv s p p.wr.(0) m, 0, repos_walk)
	end
      else if vx < 0 then
	begin
	  if p.repos <> 0 then
	    (check_inv s p p.wl.(p.frame/timer_marche) m, (p.frame mod 50)+1, repos_walk)
	  else
	    (check_inv s p p.wl.(0) m, 0, repos_walk)
	end
      else if p.repos > 0 then
	(check_inv s p p.texture m, 0, p.repos-1)
      else
	(check_inv s p p.s.(p.frame/timer_repos) m,(p.frame mod 74)+1 , 0)
    end
;;

let move_perso s (vx,vy) m =
  let p = get_perso s in
  let (text, frame, timer) = check_texture s p (vx, vy) m in
  if vy < 0 then
    begin
      if p.jumping then
	let newp = {p with speed = {vx = vx; vy = p.speed.vy}; texture = text; frame = frame; repos = timer} in
	match newp.timer_collision, newp.timer_missile with
	|0,0 -> update_perso s newp
	|70, 10 -> let newp = {newp with timer_collision = 0; timer_missile = 0} in update_perso s newp
	|0, 10 -> let newp = {newp with timer_missile = 0} in update_perso s newp
	|70, 0 -> let newp = {newp with timer_collision = 0} in update_perso s newp
	|0, _ -> let newp = {newp with timer_missile = newp.timer_missile + 1} in update_perso s newp
	|_, 0 -> let newp = {newp with timer_collision = newp.timer_collision + 1} in update_perso s newp
	|70, _ -> let newp = {newp with timer_collision = 0; timer_missile = newp.timer_missile + 1} in update_perso s newp
	|_, 10 -> let newp = {newp with timer_collision = newp.timer_collision + 1; timer_missile = 0} in update_perso s newp
	|_,_ -> let newp = {newp with timer_collision = newp.timer_collision + 1; timer_missile = newp.timer_missile + 1} in update_perso s newp
      else
	let newp = {p with speed = {vx = vx; vy = vy}; jumping = true; texture = text; frame = frame; repos = timer} in
	match newp.timer_collision, newp.timer_missile with
	|0,0 -> update_perso s newp
	|70, 10 -> let newp = {newp with timer_collision = 0; timer_missile = 0} in update_perso s newp
	|0, 10 -> let newp = {newp with timer_missile = 0} in update_perso s newp
	|70, 0 -> let newp = {newp with timer_collision = 0} in update_perso s newp
	|0, _ -> let newp = {newp with timer_missile = newp.timer_missile + 1} in update_perso s newp
	|_, 0 -> let newp = {newp with timer_collision = newp.timer_collision + 1} in update_perso s newp
	|70, _ -> let newp = {newp with timer_collision = 0; timer_missile = newp.timer_missile + 1} in update_perso s newp
	|_, 10 -> let newp = {newp with timer_collision = newp.timer_collision + 1; timer_missile = 0} in update_perso s newp
	|_,_ -> let newp = {newp with timer_collision = newp.timer_collision + 1; timer_missile = newp.timer_missile + 1} in update_perso s newp
    end
  else
    begin
      let newp = {p with speed = {vx = vx; vy = p.speed.vy}; texture = text; frame = frame; repos = timer} in
      match newp.timer_collision, newp.timer_missile with
      |0,0 -> update_perso s newp
      |70, 10 -> let newp = {newp with timer_collision = 0; timer_missile = 0} in update_perso s newp
      |0, 10 -> let newp = {newp with timer_missile = 0} in update_perso s newp
      |70, 0 -> let newp = {newp with timer_collision = 0} in update_perso s newp
      |0, _ -> let newp = {newp with timer_missile = newp.timer_missile + 1} in update_perso s newp
      |_, 0 -> let newp = {newp with timer_collision = newp.timer_collision + 1} in update_perso s newp
      |70, _ -> let newp = {newp with timer_collision = 0; timer_missile = newp.timer_missile + 1} in update_perso s newp
      |_, 10 -> let newp = {newp with timer_collision = newp.timer_collision + 1; timer_missile = 0} in update_perso s newp
      |_,_ -> let newp = {newp with timer_collision = newp.timer_collision + 1; timer_missile = newp.timer_missile + 1} in update_perso s newp
    end
;;


let is_perso_dead s =
  let rec aux l =
    match l with
    |[] -> true
    |h::t -> match h.kind with
      |Perso -> false
      |_ -> aux t
  in aux s.objets
;;

let gestion_pv s =
  {s with objets = remove_if_dead s.objets}
;;

let quit s =
  let rec aux l =
    match l with
    |[] -> ()
    |h::t -> Sdl.destroy_texture h.texture;
      aux t
  in aux s.objets;
  Sdl.destroy_renderer s.renderer;
  Sdl.destroy_window s.window;
  Sdl.quit ();
  exit 0
  
;;
