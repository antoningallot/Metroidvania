open Tsdl
open Result
open Scene
open Bigarray
open Pervasives

let movement s =
  Sdl.pump_events ();
  let t = Sdl.get_keyboard_state () in
  if t.{Sdl.get_scancode_from_key Sdl.K.escape} = 1 then quit s
  else
    let vx = 10 * t.{Sdl.get_scancode_from_key Sdl.K.right} - 10 * t.{Sdl.get_scancode_from_key Sdl.K.left} in
    let vy = -20*t.{Sdl.get_scancode_from_key Sdl.K.up} in
    let m = 1*t.{Sdl.get_scancode_from_key Sdl.K.e} - 1*t.{Sdl.get_scancode_from_key Sdl.K.a} in
    let news = creer_missiles s m in
    move_perso news (vx, vy) m
;;

let event_handler e s =
  match Sdl.poll_event (Some e) with
  |true-> 
     begin
       match Sdl.Event.enum(Sdl.Event.get e Sdl.Event.typ) with
       |`Window_event ->
	  begin
	    let n = Sdl.Event.window_event_enum(Sdl.Event.get e Sdl.Event.window_event_id) in
	    match n with
	    |`Close -> quit s
	    |_-> moveall s;
	  end
       |_ -> movement s;
     end
  |false->  moveall s
;;

let event_handler_menu e s =
  display_menu s;
  Sdl.render_present s.renderer;
  match Sdl.poll_event (Some e) with
  |true->
     begin
       match Sdl.Event.enum(Sdl.Event.get e Sdl.Event.typ) with
     |`Window_event ->
      begin
        let n = Sdl.Event.window_event_enum(Sdl.Event.get e Sdl.Event.window_event_id) in
        match n with
        |`Close -> quit s
        |_-> s
      end
     |_ ->
        begin
          let t = Sdl.get_keyboard_state () in
          if t.{Sdl.get_scancode_from_key Sdl.K.escape} = 1 then quit s
          else if t.{Sdl.get_scancode_from_key Sdl.K.s} = 1 then
	    begin
	      play_music "Son/bloody_tears.wav"; 
              let scene = create_scene s.window s.renderer niveau1 1 in
              display_list scene;
              scene
	    end
	  else s
        end
     end
  |false-> s
;;    

let rec main scene =
  if scene.state = 0 then
    let e = Sdl.Event.create () in
    let s = event_handler_menu e scene in
    main s
  else
    begin
      let b = is_perso_dead scene in
      if b then
	begin
	  Printf.printf "Reload menu\n";
	  let e = Sdl.Event.create () in
	  let scene_menu = event_handler_menu e (load_menu scene) in
	  main scene_menu
	end
      else
	begin
	  let tomovescene = movement scene in
	  let movedscene = moveall tomovescene in
	  let pvscene = gestion_pv movedscene in
	  display_list pvscene;
	  Sdl.render_present pvscene.renderer;
	  main pvscene
	end
    end
;;

let () =
  let window = create_window 1920 1080 "Metroidvania" in
  let renderer = create_renderer (-1) Sdl.Renderer.accelerated window in
  let s = create_scene window renderer menu 0 in
  main s
;;
